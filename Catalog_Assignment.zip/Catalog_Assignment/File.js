
const testCases = [
  {
    "keys": {
      "n": 4,
      "k": 3
    },
    "1": {
      "base": "10",
      "value": "4"
    },
    "2": {
      "base": "2",
      "value": "111"
    },
    "3": {
      "base": "10",
      "value": "12"
    }
  },
  {
    "keys": {
      "n": 10,
      "k": 7
    },
    "1": {
      "base": "6",
      "value": "13444211440455345511"
    },
    "2": {
      "base": "15",
      "value": "aed7015a346d63"
    },
    "3": {
      "base": "15",
      "value": "6aeeb69631c227c"
    },
    "4": {
      "base": "16",
      "value": "e1b5e05623d881f"
    },
    "5": {
      "base": "8",
      "value": "316034514573652620673"
    },
    "6": {
      "base": "3",
      "value": "2122212201122002221120200210011020220200"
    },
    "7": {
      "base": "3",
      "value": "20120221122211000100210021102001201112121"
    }
  }
];

// Function to decode a value from a given base
function decodeValue(base, value) {
  return parseInt(value, base);
}

// Function for Lagrange interpolation to find constant term c
function lagrangeInterpolation(xValues, yValues) {
  let c = 0;

  for (let k = 0; k < yValues.length; k++) {
    let L_k = (x) => {
      let result = 1;
      for (let i = 0; i < xValues.length; i++) {
        if (i !== k) {
          result *= (x - xValues[i]) / (xValues[k] - xValues[i]);
        }
      }
      return result;
    };

    // Evaluate polynomial at x=0 to find constant term c
    c += yValues[k] * L_k(0);
  }

  return Math.round(c); // Return rounded value of c
}

// Function to process each test case
function processTestCase(testCase) {
  const k = testCase.keys.k;
  const xValues = [];
  const yValues = [];

  for (let i = 1; i <= k; i++) {
    const base = parseInt(testCase[i].base);
    const value = testCase[i].value;

    xValues.push(i); // x is simply the index (1 to k)
    yValues.push(decodeValue(base, value)); // Decode y value
  }

  // Calculate constant term c
  const constantTermC = lagrangeInterpolation(xValues, yValues);
  console.log("The constant term c for test case is:", constantTermC);
}

// Process each test case
testCases.forEach(testCase => processTestCase(testCase));
